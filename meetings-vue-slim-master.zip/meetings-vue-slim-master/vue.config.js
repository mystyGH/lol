module.exports = {
  devServer: {
    proxy: 'http://[::1]:8000'
  }
};
